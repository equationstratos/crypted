# -*- coding: utf-8 -*-
xbmcgui.Dialog().ok("DEBUG", "Le script se lance bien !")
import sys
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Initialisation de l'Addon ---
# IMPORTANT : L'ID ici doit être strictement le même que dans addon.xml et le dossier
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
HASH_LIST_URL = "https://raw.githubusercontent.com/equationstratos/crypted/main/hashes.txt"

def log(msg):
    xbmc.log(f"STRATFLIX_DEBUG: {msg}", xbmc.LOGINFO)

def verifier_licence():
    """Système de verrouillage par clé SHA-256"""
    log("Lancement de la vérification de licence...")
    
    # 1. Lecture des réglages sauvegardés
    license_hash = ADDON.getSetting('stratflix_license_hash')
    activation_date = ADDON.getSetting('stratflix_date')
    
    log(f"Hash en mémoire : {license_hash}")

    # 2. Si déjà activé, on vérifie l'expiration (365 jours)
    if license_hash and activation_date:
        try:
            expiration_time = float(activation_date) + (365 * 24 * 3600)
            if time.time() < expiration_time:
                log("Licence valide trouvée en cache.")
                return True
            else:
                log("Licence expirée.")
                xbmcgui.Dialog().ok("Stratflix", "Votre accès a expiré (validité 1 an).")
        except Exception as e:
            log(f"Erreur date : {e}")
    
    # 3. Demande de saisie si rien en mémoire ou expiré
    log("Ouverture du clavier de saisie...")
    dialog = xbmcgui.Dialog()
    kb = dialog.input("Activation Stratflix (Clé de 20 caractères)", type=xbmcgui.INPUT_ALPHANUM)
    
    if not kb or len(kb) != 20:
        log("Saisie annulée ou longueur incorrecte.")
        dialog.ok("Accès Refusé", "Code invalide ou saisie annulée.\nL'application va se fermer.")
        return False
        
    # Hachage de la saisie (Majuscules forcées pour éviter les erreurs)
    saisie_hash = hashlib.sha256(kb.upper().encode()).hexdigest()
    log(f"Hash généré : {saisie_hash}")
    
    # 4. Vérification sur GitHub
    try:
        dialog.notification("Sécurité", "Vérification du code...", xbmcgui.NOTIFICATION_INFO, 3000)
        r = requests.get(HASH_LIST_URL, timeout=10)
        
        if r.status_code == 200:
            # On nettoie la liste des hashes (minuscules et sans espaces)
            hashes_valides = [h.strip().lower() for h in r.text.splitlines() if h.strip()]
            
            if saisie_hash.lower() in hashes_valides:
                log("Code validé avec succès !")
                ADDON.setSetting('stratflix_license_hash', saisie_hash)
                ADDON.setSetting('stratflix_date', str(time.time()))
                dialog.ok("Succès", "Code validé ! Bienvenue sur Stratflix.")
                return True
            else:
                log("Code absent de la liste GitHub.")
                dialog.ok("Erreur", "Code d'activation inconnu ou déjà utilisé.")
                return False
        else:
            log(f"Erreur HTTP GitHub : {r.status_code}")
            dialog.ok("Erreur Serveur", "Impossible de joindre la base de données.")
            return False
    except Exception as e:
        log(f"Erreur Réseau : {e}")
        dialog.ok("Erreur Réseau", "Vérifiez votre connexion internet.")
        return False

# --- Fonctions de Navigation ---

def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("🎭 Action", "/film-en-streaming/action/"), ("💥 Animation", "/film-en-streaming/animation/"),
        ("🥋 Arts Martiaux", "/film-en-streaming/arts-martiaux/"), ("🧗 Aventure", "/film-en-streaming/aventure/"),
        ("📜 Biopic", "/film-en-streaming/biopic/"), ("😂 Comédie", "/film-en-streaming/comedie/"),
        ("🧛 Horreur", "/film-en-streaming/epouvante-horreur/"), ("🏛️ Drame", "/film-en-streaming/drame/"),
        ("🪄 Fantastique", "/film-en-streaming/fantastique/"), ("🚔 Policier", "/film-en-streaming/policier/"),
        ("🚀 Science Fiction", "/film-en-streaming/science-fiction/"), ("🕵️ Thriller", "/film-en-streaming/thriller/")
    ]
    for name, path in genres:
        add_item(name, "list_movies", BASE_URL + path)
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'poster': thumb})
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def get_html(url, post_data=None):
    try:
        r = requests.post(url, headers={'User-Agent': USER_AGENT}, data=post_data, timeout=10) if post_data else requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    html = get_html(url, post_data)
    if not html: return
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    for item in items:
        link_tag = item.find('a', class_='mov-t')
        if link_tag:
            title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link_tag.get_text()).strip()
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            q = urllib.parse.urlencode({'action': 'select_source', 'url': link_tag['href'], 'title': title, 'thumb': thumb})
            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': thumb, 'poster': thumb})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label="▶ LIEN STREAMING")
        li.setArt({'thumb': thumb, 'poster': thumb})
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- ROUTER PRINCIPAL ---
if __name__ == '__main__':
    # Analyse des paramètres
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    # VERROU DE SÉCURITÉ
    # Si verifier_licence renvoie False, on ne lance aucune action
    if verifier_licence():
        log(f"Action demandée : {action}")
        if not action: main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else:
        log("Accès bloqué - Licence invalide.")
        # Fermeture propre du dossier Kodi
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
