# -*- coding: utf-8 -*-
import sys
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration & Sécurité ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
HASH_LIST_URL = "https://raw.githubusercontent.com/equationstratos/crypted/main/hashes.txt"

def verifier_licence():
    license_hash = ADDON.getSetting('stratflix_license_hash')
    activation_date = ADDON.getSetting('stratflix_date')
    
    # 1. Vérification si déjà activé
    if license_hash and activation_date:
        try:
            expiration_time = float(activation_date) + (365 * 24 * 3600)
            if time.time() < expiration_time:
                return True
        except: pass

    # 2. Demande de clé
    kb = xbmcgui.Dialog().input("Activation Stratflix (20 caractères)", type=xbmcgui.INPUT_ALPHANUM)
    if not kb or len(kb) != 20:
        xbmcgui.Dialog().ok("Erreur", "Clé invalide.")
        return False
        
    saisie_hash = hashlib.sha256(kb.upper().encode()).hexdigest()
    
    # 3. Vérification distante
    try:
        r = requests.get(HASH_LIST_URL, timeout=10)
        if r.status_code == 200:
            hashes_valides = [h.strip().lower() for h in r.text.splitlines() if h.strip()]
            if saisie_hash.lower() in hashes_valides:
                ADDON.setSetting('stratflix_license_hash', saisie_hash)
                ADDON.setSetting('stratflix_date', str(time.time()))
                xbmcgui.Dialog().ok("Succès", "Activé !")
                return True
    except: pass
    
    xbmcgui.Dialog().ok("Erreur", "Clé refusée ou pas de connexion.")
    return False

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("🎭 Action", "/film-en-streaming/action/"), ("💥 Animation", "/film-en-streaming/animation/"),
        ("🥋 Arts Martiaux", "/film-en-streaming/arts-martiaux/"), ("🧗 Aventure", "/film-en-streaming/aventure/"),
        ("📜 Biopic", "/film-en-streaming/biopic/"), ("😂 Comédie", "/film-en-streaming/comedie/"),
        ("🧛 Horreur", "/film-en-streaming/epouvante-horreur/"), ("🏛️ Drame", "/film-en-streaming/drame/"),
        ("🪄 Fantastique", "/film-en-streaming/fantastique/"), ("🚔 Policier", "/film-en-streaming/policier/"),
        ("🚀 Science Fiction", "/film-en-streaming/science-fiction/"), ("🕵️ Thriller", "/film-en-streaming/thriller/")
    ]
    for name, path in genres:
        add_item(name, "list_movies", BASE_URL + path)
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'poster': thumb})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping ---

def get_html(url, post_data=None):
    try:
        r = requests.post(url, headers={'User-Agent': USER_AGENT}, data=post_data, timeout=10) if post_data else requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    html = get_html(url, post_data)
    if not html: return
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    for item in items:
        link_tag = item.find('a', class_='mov-t')
        if link_tag:
            title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link_tag.get_text()).strip()
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            q = urllib.parse.urlencode({'action': 'select_source', 'url': link_tag['href'], 'title': title, 'thumb': thumb})
            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': thumb, 'poster': thumb})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label="▶ LIEN STREAMING")
        li.setArt({'thumb': thumb, 'poster': thumb})
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router Principal ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    # LE VERROU : On vérifie TOUJOURS avant d'exécuter l'action
    if verifier_licence():
        if not action: main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else:
        # Si la licence échoue, on ferme proprement le répertoire Kodi
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
